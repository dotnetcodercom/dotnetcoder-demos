// Copyright (c) .NET Foundation. All rights reserved.
// Licensed under the MIT License. See License.txt in the project root for license information.

using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Microsoft.Azure.WebJobs.Script.Workers.Rpc
{
    internal interface IWebHostRpcWorkerChannelManager
    {
        Task<IRpcWorkerChannel> InitializeChannelAsync(IEnumerable<RpcWorkerConfig> workerConfigs, string language);

        IDictionary<string, TaskCompletionSource<IRpcWorkerChannel>> GetChannels(string language);

        Task SpecializeAsync();

        Task<bool> ShutdownChannelIfExistsAsync(string language, string workerId, Exception workerException);

        Task ShutdownChannelsAsync();

        Task WorkerWarmupAsync();
    }
}
