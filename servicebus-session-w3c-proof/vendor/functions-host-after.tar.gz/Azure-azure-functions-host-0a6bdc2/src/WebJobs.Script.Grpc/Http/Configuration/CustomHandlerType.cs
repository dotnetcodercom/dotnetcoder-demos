// Copyright (c) .NET Foundation. All rights reserved.
// Licensed under the MIT License. See License.txt in the project root for license information.

namespace Microsoft.Azure.WebJobs.Script.Workers.Http
{
    internal enum CustomHandlerType
    {
        Http = 0,
        None = 1
    }
}
