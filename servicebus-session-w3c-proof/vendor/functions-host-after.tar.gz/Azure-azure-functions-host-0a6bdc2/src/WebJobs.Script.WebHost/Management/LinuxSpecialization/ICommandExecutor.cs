﻿// Copyright (c) .NET Foundation. All rights reserved.
// Licensed under the MIT License. See License.txt in the project root for license information.

using System.Collections.Generic;

namespace Microsoft.Azure.WebJobs.Script.WebHost.Management.LinuxSpecialization
{
    public interface ICommandExecutor
    {
        (string Output, string Error, int ExitCode) RunCommand(string fileName, IEnumerable<string> arguments, string metricName);
    }
}